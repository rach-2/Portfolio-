 var thisApp = angular.module("theApp",[]);
thisApp.controller('theController' , function($scope) {

$scope.fristWord ="hello" ;
$scope.secondWord ="user";
$scope.bothWords = function() {
 return $scope.fristWord + " " + $scope.secondWord ;

}


});