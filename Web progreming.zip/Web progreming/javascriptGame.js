function init(){

	var canvas  = document.getElementById("myCanvas");
	var cContext = canvas.getContext("2d");
 
	var balls = new Array(6);
	
	// Fill array with random numbers
	
      for(i = 0 ; i < 6; i++){
	     balls[i] = Math.floor(Math.random()*49+1);
	  }
	
	// Display the balls showing the random numbers
	var x = 50;
	var y = 100;
	var r = 40;

	for(i = 0;  i < 6; i++){
		cContext.beginPath();
		//cContext.arc(x*(i+1),250,50,0,2*Math.PI);
		cContext.arc(x,y,r,0,2*Math.PI);
		cContext.stroke();
		
		cContext.fillText(balls[i], x, y );
		
		x+=100;
		
	
	}
}