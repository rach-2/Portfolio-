alert("Hello");

var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");

ctx.beginPath();
ctx.arc(200,100,40,0,2*Math.PI);
ctx.stroke();