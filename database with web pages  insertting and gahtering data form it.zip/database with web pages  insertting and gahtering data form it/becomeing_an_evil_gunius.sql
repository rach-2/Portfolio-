-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2014 at 07:15 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `becomeing_an_evil_gunius`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `hoursworked`
--
CREATE TABLE IF NOT EXISTS `hoursworked` (
`StaffID` int(11)
,`sum(HoursPerWeek)` decimal(32,0)
);
-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `ModuleCOde` varchar(7) NOT NULL DEFAULT '',
  `ModuleTilte` varchar(60) DEFAULT NULL,
  `Semester` int(11) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `StaffID` int(11) DEFAULT NULL,
  `HoursPerWeek` int(11) DEFAULT NULL,
  PRIMARY KEY (`ModuleCOde`),
  KEY `StaffID` (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`ModuleCOde`, `ModuleTilte`, `Semester`, `Year`, `StaffID`, `HoursPerWeek`) VALUES
('evx3001', 'fundemtals of world domenartion', 1, 0, 1, 5),
('EVX3002', 'Ploting for beginers', 2, 0, 1, 5),
('EVX3003', 'intorduction to lier bluding', 1, 0, 2, 5),
('EVX3004', 'Frodation Project', 2, 0, 4, 5),
('EVX3005', 'Subvwertiy Soctitery', 1, 0, 3, 5),
('EVX3006', 'Gadgets and Gizmos', 2, 0, 5, 5),
('EVX4000', 'curring Plan', 1, 1, 6, 5),
('EVX4001', 'Comunacation Of Demands', 2, 1, 2, 5),
('EVX4002', 'Recongiesing spices', 2, 1, 9, 5),
('EVX4003', 'Dungeon Design', 1, 1, 7, 5),
('EVX4004', 'Coustume Design', 2, 1, 10, 5),
('EVX4005', 'Traps and Pitfalss', 1, 1, 8, 5),
('EVX5001', 'level 2 projet', 2, 2, 2, 4),
('EVX6000', 'the eftinus of evil', 1, 3, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `StaffID` int(11) NOT NULL,
  `staffName` varchar(40) DEFAULT NULL,
  `staffRoomNumber` int(11) DEFAULT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `staffName`, `staffRoomNumber`) VALUES
(1, 'Mike Brouton', 42),
(2, 'Steve micthial', 102),
(3, 'david adems', 36),
(4, 'christphor rhicreds', 36),
(5, 'isobel ashworth', 99),
(6, 'Glen Gardens', 55),
(7, 'Richard Abarhams', 75),
(8, 'nail Cotsworld', 65),
(9, 'barrie little', 13),
(10, 'Tom Biggins', 88);

-- --------------------------------------------------------

--
-- Structure for view `hoursworked`
--
DROP TABLE IF EXISTS `hoursworked`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hoursworked` AS select `modules`.`StaffID` AS `StaffID`,sum(`modules`.`HoursPerWeek`) AS `sum(HoursPerWeek)` from `modules` group by `modules`.`StaffID`;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`StaffID`) REFERENCES `staff` (`StaffID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
