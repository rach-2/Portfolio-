<html>
<head>
</head>
<body>
 <?php
 

$moduleCode =  $_POST["ModuleCode"];
$moduleTitle =  $_POST["ModuleTitle"];
$semseter =  $_POST["semester"];
$year =   $_POST["year"] ;
$staffID =   $_POST["staffID"];
$hoursPerWeeek =  $_POST["hoursPerWeek"];

$dbserver = "localhost";
$dbusername = "root";
$dbpassword = "";

$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connent to database");
$dbname = "becomeing_an_evil_gunius";
$selectto = mysqli_select_db($connection,$dbname) or die ("could not acess database");

$sqlstatement = "INSERT INTO Modules VALUES('$moduleCode' , '$moduleTitle' , $semseter , $year , $staffID , $hoursPerWeeek)";
echo "$sqlstatement";
$sqlresult = mysqli_query($connection,$sqlstatement) or die ("could not isuse sql insert  statement");







?>

</body>

<html>
