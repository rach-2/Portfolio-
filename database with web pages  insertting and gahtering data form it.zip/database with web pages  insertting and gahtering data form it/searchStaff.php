<html>
<head>
<title> Staff Search </title>

</head>
<body>
 
 <?php

$staffID = $_POST["staff"];  
$dbserver = "localhost";
$dbusername = "root" ;
$dbpassword = ""; 




$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connect server");


$dbname = "becomeing_an_evil_gunius";
$selectto = mysqli_select_db($connection,$dbname) or die ("could not access database");

$sqlstatement = "SELECT  ModuleCOde , ModuleTilte , staffName , Staff.StaffID FROM modules , staff WHERE modules.staffID = '$staffID' And staff.StaffID = Modules.StaffID";

$sqlresult = mysqli_query($connection,$sqlstatement) or die ("could not isuse sql return statement");

while($row = mysqli_fetch_array($sqlresult)){

 $mc = $row["ModuleCOde"];
 $mt = $row  ["ModuleTilte"];
 $sn = $row  ["staffName"];
  $sid = $row["StaffID"];
 echo " ModuleCode $mc  module Tilte $mt Staff name : $sn staff id: $sid" ;

 }

?>

</body>
</html>