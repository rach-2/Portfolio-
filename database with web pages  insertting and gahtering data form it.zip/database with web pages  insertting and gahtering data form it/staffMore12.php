</head>
<body>
 <?php
 



$dbserver = "localhost";
$dbusername = "root";
$dbpassword = "";

$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connect server");
$dbname = "becomeing_an_evil_gunius";
$selectto = mysqli_select_db($connection,$dbname) or die ("could not acess database");

$sqlstatement = "SELECT staffID , sum(hoursPerWeek FROM HoursPerWeek WHERE ModuleCOde = sum(HoursPerWeek > 12";
$sqlresult = mysqli_query( $connection,$sqlstatement) or die ("could not isuse sql return statement");

while($row = mysqli_fetch_array($sqlresult)){
 $sid = $row["staffID"];
 $hpw = $row["sum(HoursPerWeek"];
 
 
 echo "$sid $hpw" ;



}


?>
