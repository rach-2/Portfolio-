</head>
<body>
 <?php
 



$dbserver = "localhost";
$dbusername = "root";
$dbpassword = "";

$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connect server");
$dbname = "becomeing_an_evil_genius";
$selectto = mysqli_select_db($dbname,$connection) or die ("could not acess database");

$sqlstatement = "SELECT moduleCOde FROM modules WHERE staffID = ''";
$sqlresult = mysqli_query($sqlstatement,$connection) or die ("could not isuse sql sellcet statement");

while($row = mysqli_fetch_array($sqlresult)){
 $sid = $row["staffID"];

 
 
 echo "$sid,  ;



}


?>
