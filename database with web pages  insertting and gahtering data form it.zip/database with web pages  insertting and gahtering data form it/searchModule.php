<html>
<head>
<title> Staff Search </title>

</head>


<body>
 <?php
$moduleCode = $_POST["module"];


$dbserver = "localhost";
$dbusername = "root";
$dbpassword = "";

$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connect server");


$dbname = "becomeing_an_evil_gunius";
$selectto = mysqli_select_db($connection,$dbname) or die ("could not access database");

$sqlstatement ="SELECT modules.StaffID, ModuleCOde , ModuleTilte ,staffName FROM modules , staff WHERE ModuleCOde = '$moduleCode' AND modules.StaffID = staff.StaffID; " ;

$sqlresult = mysqli_query($connection,$sqlstatement) or die ("could not isuse sql return statement");  

while($row = mysqli_fetch_array($sqlresult)){
$sid = $row["StaffID"];
$mc = $row["ModuleCOde"];

$mt = $row["ModuleTilte"];
$sn = $row["staffName"];
 





 
 echo " Staff ID $sn Module Code $mc Module tilte $mt staff name : $sn " ;



}

?>
</body>
</html>


