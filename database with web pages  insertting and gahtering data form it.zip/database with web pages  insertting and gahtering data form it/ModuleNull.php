</head>
<body>
 <?php
 



$dbserver = "localhost";
$dbusername = "root";
$dbpassword = "";

$connection = mysqli_connect($dbserver, $dbusername, $dbpassword) or die("could not connect server");
$dbname = "becomeing_an_evil_genius";
$selectto = mysql_select_db($dbname,$connection) or die ("could not acess database");

$sqlstatement = "SELECT ModuleCOde FROM modules WHERE staffID = NULL"
$sqlresult = mysql_query($sqlstatement,$connection) or die ("could not isuse sql return statement");

while($row = mysql_fetch_array($sqlresult)){
 $mc = $row["ModuleCOde"];

 
 echo "$mc" ;



}


?>
