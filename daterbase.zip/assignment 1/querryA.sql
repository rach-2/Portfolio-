/*
Name: qaueeryF
3/3/16
Rachel lowe
*/
SELECT accomadationStaffId, hallsId FROM halls, accomadationStaff GROUP BY hallsId;