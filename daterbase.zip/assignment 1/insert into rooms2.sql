/* insert into rooms2
date 1/1/12
gentreated by mockaroo
Rachel lowe
*/
INSERT INTO rooms (placeNumber, flatNumber, roomNumber) VALUES (2, 2, 5), (3, 3, 2), (4, 4, 4), (5, 5, 2), (6, 6, 5), (7, 6, 2), (8, 10, 1), (9, 12, 5), (10, 11, 2), (11, 12, 3),
(12, 5, 1); 