/*
name: create table halls
author: rachel lowe
date: 26/11/15
*/
CREATE TABLE halls (
hallsId integer PRIMARY KEY NOT NULL, 
manger string REFERENCES accomadtionStaff(staffId), Name string NOT NULL
, address string NOT NULL, 
telNumber string NOT null
);