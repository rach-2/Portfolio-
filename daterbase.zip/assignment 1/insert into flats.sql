/*
Name insert into flats
auhtor: rachel lowe
Date: 1/1/16
*/
INSERT INTO flats
(flatNumber, 'flatadresss' , numberOfrooms)
VALUES(1, " tyme steet orlando halls of redisisnce, thyme steet bl2 1nw", 3);