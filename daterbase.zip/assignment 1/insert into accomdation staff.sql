
insert into accomadationStaff
( accomadationStaffId,'fristName','lastName', 'houseNUmberOrname','street', 'type'  ,  'sex' ,'location')
values(1, "joe" , "blogs", "4", "radciffle road", "manger" , "male" , "halls");
