/*
Name; create talbe flat insepction
Auhtor: rachel lowe
date: 1/1/16
*/
CREATE TABLE flatInsperctions
(id integer PRIMARY KEY,
staffFristName string REFERENCES accomadationStaff(FristName),
staffLastName string REFERENCES acomadationStaff(lastName),
date datetime,
satafastiyCondation boolean
);
