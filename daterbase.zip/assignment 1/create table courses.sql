/*
 Name: create table course
 Author: Rachel lowe
 Date: 12/11/15
*/
CREATE TABLE courses
(courseNumber integer PRIMARY KEY NOT NULL,
courseTilteAndYear string NOT NULL,
courseLeader string NOT NULL,
internalTelephone string NOT NULL, 
roomNumber integer NOT NULL )