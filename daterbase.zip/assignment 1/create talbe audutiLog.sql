/*
create table auiitlog
date 30/12/15
author: rachel
*/
CREATE TABLE auditLog(
id integer,
tableName string,
date datetime);