/*
name create triger audit flats
atuhor: Rachel lowe
date 31/12/15
*/ 
CREATE TRIGGER auditFlats
AFTER INSERT ON flats
BEGIN
INSERT INTO auditLog
(id, 'tablename', date)
VALUES(new.ID, 'flats' , date(now));
END