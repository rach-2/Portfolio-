/*
Name: create table accomatiotionStaff
Author: rachel lowe
Date 24/11/2015
*/
CREATE TABLE accomadationStaff
( accomadationStaffId integer PRIMARY KEY NOT NULL,
 fristName string NOT NULL, 
 lastName string NOT NULL, 
 houseNUmberOrname string NOT NULL, 
 street string NOT NULL,
  type string NOT NULL, 
  sex string NOT NULL,
  location string NOT NULL ); 
