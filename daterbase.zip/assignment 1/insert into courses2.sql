/*
Name insert into corses2
greanted by my mockaroo
Date: 2/2/16
Rachel lowe
*/
INSERT INTO courses ('courseNumber', 'CourseLeader', 'courseTitleAndYear' , 'internalTelePhone', 'roomNumber') VALUES (2, "Clarence Porter", "MathsYear2", "1-(206)607-9206", 53), (3, "Rachel Rose", "ComputingYear3" ,"63-(155)829-9787", "19"), (4, "Carol Williamson","phiysogllyYear1","380-(445)280-2695", "14"), (5, "Ryan Armstrong", "ProformeringArtsYear2", "509-(878)272-5679", "82"), (6, "Amy Chavez", "mathsYear3","46-(669)465-5780", "52"), (7, "Evelyn Howell" ,"scinceYear2", "86-(890)344-0230", "81"), (8, "Gloria Fields", "EngishYear1" , "86-(290)328-4974", "65"), (9, "Brandon Welch", "Scince Year3" , "(522)362-0201", "84"), (10, "William Harper", "scince Year2", "972-(213)862-2745", "49"),
(11, "Donna Hall", "mathsYear1","52-(235)290-8287", "12"), (12, "Marie Morgan", "englishYear2" , "7-(189)159-3070", "17");
