/*
Name: create table rooms
Author: rachel lowe
Date 31/12/2015
*/
CREATE TABLE rooms
(PlaceNumber integer PRIMARY KEY,
FlatNumber integer REFERENCES flats(flatNUmber),
RoomNumber integer
);