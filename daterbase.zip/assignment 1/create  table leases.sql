/*
Name: create table leases
author: rachel lowe 
date 26/11/15
*/
CREATE TABLE leasses
(leaseNUmber integer PRIMARY KEY NOT NULL, 
studentNumber string REFERENCES students(studentId), 
studentFristName string REFERENCES students(studentfristName), 
studentLastName string REFERENCES students(studentLastName), 
placeNumber REFERENCES  rooms(placeNumber),
roomNUmber REFERENCES room(roomNumber),
flatAdresss string,
dateOfEnty datetime ); 