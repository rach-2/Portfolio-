/*insert into flats2
gentatted by mockaroo
date: 1/1/16
rahel lowe
*/
INSERT INTO flats (flatNumber, flatadresss, numberOfrooms) VALUES (2, '1 Warrior Court', 3),
(3, '584 Spohn Hill', 3),
 (4, '957 Ilene Terrace', 4),  (5, '844 Hazelcrest Point', 4),
(6, '516 Eagan Point', 5),
(7, '27367 Sommers Road', 4),
(8, '14 Ruskin Trail', 5),
(9, '9769 Northland Lane', 3),
 (10, '843 Schiller Parkway', 3),
 (11, '15787 Nancy Drive', 5),
  (12, '40 Washington Road', 4)
