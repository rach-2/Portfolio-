
/*
queery 9
3/3/16
rachel lowe
*/
select studnetNumber studentFristName, studentlastName, roomNumber, hallsId from students, halls , rooms  where hallsId = 1;