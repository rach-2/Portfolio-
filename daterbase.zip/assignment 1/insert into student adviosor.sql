/*
name insert into student advisors
author: rachel Lowe
Date 1/1/16
*/
INSERT INTO studentAdvisors
(id ,'fristName','LastName','roomNumber','departemnt','internalTelephoneNumber')
VALUES(1, "John", "smith", "b2.009", "technogally", "089890000009");