/*
Name: create table lesses
author: rachel lowe 
date 26/11/15
*/
CREATE TABLE lesses
(id integer PRIMARY KEY NOT NULL, 
studentNumber string REFERENCES students(studentId), 
studentFristName string REFERENCES students(studentfristName), 
studentLastName string REFERENCES students(studentLastName), 
dateOfEnty datetime ); 