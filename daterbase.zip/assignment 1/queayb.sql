
/*
queery b
4/3/16
rachel lowe
*/
select * from leasses;

