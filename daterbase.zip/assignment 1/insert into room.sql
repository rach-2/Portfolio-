/*
 Name: insert into rooms;
 date 1/1/16
 author: rachel lowe
*/
INSERT INTO rooms
(PlaceNumber, flatNumber, roomNumber)
VALUES(1,1,2);
