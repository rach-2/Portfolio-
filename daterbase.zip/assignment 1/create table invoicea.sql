create table invovies 
(invoiceNumber integer primary key,
leaseNumber ingteger references leases(LeaseNumber),
StudentNumber integer  references studetns(studentNumber),
studentFristName string references students(studentFristName),
studentLastName string references students(studentLastName),
placeNUmber integer references rooms(placeNumber)

);