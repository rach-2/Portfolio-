
/*
queery i
4/3/16
rachel lowe
*/
COUNT(*) from students group by categorry;

