/*
Name create triger auditHalls
Author: Rachel Lowe
Date 22/12/15
*/
CREATE TRIGGER auditHalls
AFTER INSERT ON halls 
BEGIN
INSERT INTO audit (id, 'table', date)
VALUES(halls.hallsId, "halls", date(now));
END