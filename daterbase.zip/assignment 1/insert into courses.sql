/*
Name: insert into courses
Auhtor: rachel Lowe
Date; 1/1/16
*/
INSERT INTO courses
(courseNumber, 'courseTitleAndYear' , 'courseLeader' , 'internalTelephone', 'roomNumber')
VALUES(1, "Computing", "claras oslwaord", "098876589098", "3456");
