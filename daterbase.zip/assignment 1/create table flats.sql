/*
Name: creaate table flats
auhtor: Rachel lowe
Date 9/10/2015
 */
CREATE TABLE flats(
flatNumber Integer PRIMARY KEY NOT NULL,
flatAdresss string NOT NULL,
numberOfRooms integer
);
/*

