/*
Name: create table students
Author: rachel lowe
Date 12/11/2015
dealted and recearted on 1/1/16
dealted and recearted on 3/1/16
*/

CREATE TABLE students
( StudnetNumber integer PRIMARY KEY NOT NULL, 
studentFristName string NOT NULL, 
studentLastName string NOT NULL, 
studentAdressFristLine string NOT NULL,
 studentAdressSecondLine string, 
 sudentPostCode string NOT NULL, 
 somker boolean DEFAULT false, 
 catorgory string, 
  course String,
   sattus string, 
  nextOfKin String, 
  nextOfKinAdressFristLine string, 
  nextOfkinAdresssSecondLine string, 
  nextOfkinPostCode string, 
  PlaceNumber ingteger REFERENCES rooms(placeNumbe) );