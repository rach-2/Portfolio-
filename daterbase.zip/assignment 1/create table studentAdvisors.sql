/*
name: create table studentAdvisors 
author: rachel 
Date: 23/12/15
droped and recrated on 1/1/16
*/
CREATE TABLE studentAdvisors
(id integer PRIMARY KEY NOT NULL,
fristName string NOT NULL,
LastName string NOT NULL,
roomNumber string NOT NULL,
departemnt string NOT NULL,
internalTelaphoneNumber NOT NULL);