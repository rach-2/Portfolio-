package Gui;

public interface GuiInterface {
	
	
public void CreateGui();

	
	
	

}
