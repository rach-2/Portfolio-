package Gui;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Applacation.Frog;

public class Gui implements GuiInterface  {
 JPanel petPenel,buttonPanel,petName;
	@Override
	public void CreateGui() {
		
		
	}
	

}
