package Applacation;

public class Mouse {

}
