package Applacation;

public class Cat {

}
