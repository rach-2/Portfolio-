

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;




/**
 * 
 * @author Rachel Lowe
 *
 */

public class FrogGUI extends JFrame  implements ActionListener
{
	  //here i am delcareing varbles that i will use in my p
     JButton makePet ,  hungryButton , resetButton;
     JTextField petName;
     JTextArea  hungryTextArea;
     JPanel totalGUI, buttonPanel, petNamePanel , petPanel  ;
     Frog frog;
     Fly fly;
     Thread frogThread;
     Thread flyThread;
    
    String name;
	ArrayList<Frog>  frogs = new ArrayList<Frog>();
	
	
  
   
 
  

	 
/**
 * 
 * @return
 */
public JPanel createContentPane(){
	
	//here i am instaily variables 
	
	totalGUI = new JPanel();
	totalGUI.setSize(800,600);
	

	 petPanel = new JPanel();
     petPanel.setPreferredSize(new Dimension(600,500));
	 petPanel.setBackground(Color.white);
     totalGUI.add(petPanel);
     
     
     buttonPanel = new JPanel();
    buttonPanel.setSize(100, 100);
    buttonPanel.setLocation(100, 200);
    totalGUI.add(buttonPanel);
    
    
    
    
	 
	 
	 petNamePanel = new JPanel();
	 petNamePanel.setSize(200,200);
	 petNamePanel.setLocation(100, 100);
	 totalGUI.add(petNamePanel);
	
	 
	 
	 //totalGUI.setLayout(new BorderLayout());
	//buttonPanel.setLayout (new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
     // petPanel.setLayout(new FlowLayout());
	//petNamePanel.setLayout(new BoxLayout(petNamePanel, BoxLayout.Y_AXIS));
    //textAreaPanel.setLayout(new FlowLayout());
	  
	  //totalGUI.add(petPanel);
	 // totalGUI.add(buttonPanel);
	  //totalGUI.add(petNamePanel);
	 // totalGUI.add(textAreaPanel);

	

	petName = new JTextField("plesee enter name for your pet");
	
	
	petName.setLocation(20,20);
    petNamePanel.add(petName);


	
     makePet = new JButton();
	 makePet.setText("Make pet");
	 makePet.addActionListener(this);
	 buttonPanel.add(makePet);
	 
	 hungryButton = new JButton("Hungry");
	 hungryButton.addActionListener(this);
	
	 buttonPanel.add(hungryButton);
	
	
	 resetButton = new JButton("reset");
	 resetButton.addActionListener(this);
	 buttonPanel.add(resetButton);
	 
	hungryTextArea = new JTextArea();
	hungryTextArea.setSize(100,100);
	hungryTextArea.setLocation(100,100);
    petNamePanel.add(hungryTextArea);
    
	
	totalGUI.setOpaque(true);
	 
    return totalGUI;
	
	

	
	
}


/**
 * 
 */
public void actionPerformed(ActionEvent evt) {

	if (evt.getSource() == makePet){
		
		if (petName.getText().equals("") || petName.getText().equals("plesee enter name for your pet")){
		 
	    JOptionPane.showMessageDialog(totalGUI, "Pet Must have a name");
		
	    }
	 
	  else 
	  {
		
		 frog = new Frog();
		 frog.setName(petName.getText());
		  
		 frogs.add(frog);
		   
		 petPanel.add(frog.drawFrog());
		 
		
		  fly = new Fly();
		 
		 petPanel.add(fly.drawFly());
		 
		 
		  frogThread = new Thread(frog);
		 frogThread.start();
		  flyThread = new Thread(fly);
		 flyThread.start();
		 
		 
		 
		 
		 
		 
		
		    
	
	  }
	  
	  
	 
	  
	}
	 if (evt.getSource() == hungryButton ){
		 String frogNames = "";
		  
			for (Frog f: frogs){
				
				frogNames = frogNames + f.getName() + ", "   ;
		
		
			 frog.setLocation(fly.getLocation());
			
			 frog.setHungry(fly);
			 
						
			
			
	
			}
			
			if(frogs.size() == 1) {
			hungryTextArea.setText(frogNames + " is hungry");
			
			}
			else {
				
				hungryTextArea.setText(frogNames + " are hungry");
			}
			

			
		}
		
		if ( evt.getSource() == resetButton){
			
			hungryTextArea.setText(null);
			
			petPanel.removeAll();
			
		}
		
		
	
		

		
}


	
public static void createAndShowGUI(){
	JFrame.setDefaultLookAndFeelDecorated(true);
    JFrame frame = new JFrame("HungryPet");
    frame.setSize(900,650);
    
    FrogGUI fg = new FrogGUI() ;
    frame.setContentPane(fg.createContentPane());
    		
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     frame.setVisible(true);
	

	
	
	
}



	





public static void main (String[] args){
	SwingUtilities.invokeLater(new Runnable(){

		@Override
		public void run() {
			createAndShowGUI();
			
		
			
		
			
			
		}
		
	});
}









}

