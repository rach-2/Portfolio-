





import javax.swing.*;

import java.awt.* ;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Random;

public class Frog extends FrogGUI  implements Runnable{
	
	
private String name;
JLabel frogLabel;
Random rPoint;
private boolean flag=false;
int x,y=0;
Fly fly;

public void setName(String name){
	this.name = name;
}

public String getName(){
	return name;
}
		
	  public JLabel drawFrog(){
		  
		  System.out.println("drawMethod");
	   ImageIcon frogImage = new ImageIcon("M:\\frog\\frog.jpg");
	   
	   
	    frogLabel = new JLabel();
	    
	   frogLabel.setIcon(frogImage);
	     frogLabel.setLocation((int) Math.random(), (int) Math.random());
	   return frogLabel;
	   
	   
	
	   
			  
	  }
	  private void hungry()
	  {
		  x=fly.getX();
		  y=fly.getY();
		  frogLabel.setLocation(x,y);
	  }
	  
	  private void randomMove()
	  {
		  rPoint = new Random();
		  x=rPoint.nextInt(400);
		  y=rPoint.nextInt(150);
	  }
	
	  public void setHungry(Fly f)
	  {
		  flag=true;
		  fly=f;
	  }

	@Override
	public void run() {
		
		 rPoint = new Random();
		
		while (true){
			
		if(flag==false)
		{
		frogLabel.setLocation(rPoint.nextInt(400), rPoint.nextInt(150));
		}
		else
		{
			hungry();
		}
		
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		}
		
	}

	
	}
	 

