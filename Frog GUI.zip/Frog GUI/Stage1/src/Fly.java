

import java.awt.*;
import java.util.Random;

import javax.swing.*;



public class Fly extends FrogGUI implements Runnable  {
	JPanel flyPanel;
	Random rPoint;
	int x,y=0;
	
	public JPanel drawFly(){
		flyPanel = new JPanel();
		
		
		flyPanel.setSize(5,5);
		flyPanel.setBackground(Color.BLACK);
	
		
		
		return flyPanel;
		
	}
	
public int getX()
{
	return x;
	
}
	
public int getY()
{
	return y;
}

@Override
public void run() {
    while(true){
    	Random rPoint = new Random();
    	
    	flyPanel.setLocation(rPoint.nextInt(500), rPoint.nextInt(200));
    	try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	
}


	

	

	
	

	
	}


	
	
	


